<?php $__env->startPush('filter-required'); ?>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4 class="text-center">Generar ingreso de artículos</h4>

        <div class="row justify-content-center my-4">
            <div class="col-12 col-md-6">
                <div class="h5 text-center">Datos del ingreso</div>
                
                <form action="<?php echo e(route('entry.store')); ?>" method="post" class="formCreate">
                    <?php echo csrf_field(); ?>
                    <div class="row form-group">
                        <label for="provider_id"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>PROVEEDOR<span
                                    class="text-danger">*</span>:</b></label>
                        <div class="col-12 col-md-7">
                            <select name="provider_id" id="provider_id" required data-live-search="true" data-size="5"
                                class="<?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> catalog-select">
                                <option value="">Selecciona un proveedor...</option>
                                <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($provider->id); ?>" <?php if($provider->id == old('provider_id')): ?> selected <?php endif; ?>><?php echo e($provider->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="office_id"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>SUCURSAL<span
                                    class="text-danger">*</span>:</b></label>
                        <div class="col-12 col-md-7">
                            <select name="office_id" id="office_id" required data-live-search="true" data-size="5"
                                class="<?php $__errorArgs = ['office_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> catalog-select">
                                <option value="">Selecciona una sucursal...</option>
                                <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($office->id); ?>" <?php if($office->id == old('office_id')): ?> selected <?php endif; ?>>
                                        <?php echo e($office->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['office_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="type" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>TIPO DE
                                INGRESO<span class="text-danger">*</span>:</b></label>
                        <div class="col-12 col-md-7">
                            <select name="type" id="type" class="<?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> custom-select"
                                required>
                                <option value="">Selecciona el tipo de ingreso...</option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->id); ?>" <?php if($type->id == old('type')): ?> selected <?php endif; ?>>
                                        <?php echo e($type->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="mandated"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>ENCARGADO DEL
                                INGRESO<span class="text-danger">*</span>:</b></label>
                        <div class="col-12 col-md-7">
                            <input type="text" name="mandated" id="mandated" required
                                class="form-control <?php $__errorArgs = ['mandated'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Escribe quién es el encargado de este ingreso"
                                value="<?php echo e(old('mandated')); ?>">
                            <?php $__errorArgs = ['mandated'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="purchase_date"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>FECHA DE SOLICITUD<span
                                    class="text-danger">*</span> :</b></label>
                        <div class="col-12 col-md-7">
                            <input type="date" name="purchase_date" id="purchase_date" required
                                class="form-control <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Escribe quién es el encargado de este ingreso"
                                value="<?php echo e(old('purchase_date') ?? date('Y-m-d')); ?>">
                            <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="purchase_order"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>ORDEN DE
                                COMPRA:</b></label>
                        <div class="col-12 col-md-7">
                            <input type="text" name="purchase_order" id="purchase_order"
                                class="form-control <?php $__errorArgs = ['purchase_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Escribe la OC (si existe)" value="<?php echo e(old('purchase_order')); ?>">
                            <?php $__errorArgs = ['purchase_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group justify-content-center">
                        <div class="col-auto">
                            <button type="button" class="btn btn-sm btn-secondary" data-toggle="modal"
                                data-target="#cancelEntryModal">Cancelar ingreso</button>
                            
                        </div>
                        <div class="col-auto">
                            <?php if(Auth::user()->can('edit_inventory')): ?>
                                <button type="button" class="btn btn-sm btn-primary" id="btnConfirmEntry">Confirmar
                                    ingreso</button>
                            <?php else: ?>
                                <button type="button" class="btn btn-sm btn-dark" disabled>❌</button>
                            <?php endif; ?>

                        </div>
                    </div>

                    <div class="row justify-content-center my-3 d-none" id="rowFormIncomplete">
                        <div class="col-10 text-center alert alert-danger font-weight-bolder">
                            Completa los campos con un <span class="text-danger">*</span>
                        </div>
                    </div>

                </form>
            </div>

            <div class="col-12 col-md-6">
                
                <div class="h5 text-center">Articulos a ingresar</div>
                <div class="row form-group">
                    <label for="catalog_search"
                        class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Catalogo:</b></label>
                    <div class="col-12 col-md-7 text-center">
                        <select name="catalog_search" id="catalog_search" class="catalog-select" data-live-search="true"
                            data-size="5">
                            <option class="font-weight-bold" value="">Buscar...</option>
                            <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="font-weight-bold" value="<?php echo e($catalog->id); ?>">
                                    <?php echo e($catalog->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                
                <form action="" id="itemListForm">
                    <div class="row form-group">
                        <div class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Nombre corto:</b></div>
                        <div class="col-12 col-md-7">
                            <input type="text" name="catalog_name" id="catalog_name" class="form-control" disabled>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-12 col-md-5 text-center text-md-right align-self-center"><b>SKU:</b></div>
                        <div class="col-12 col-md-7">
                            <input type="text" name="catalog_sku" id="catalog_sku" class="form-control" disabled>
                        </div>
                    </div>

                    <input type="hidden" name="catalog_id" id="catalog_id">

                    <div class="row form-group">
                        <label for="item_serie" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>N°
                                Serie<span class="text-danger">*</span>:</b></label>
                        <div class="col-12 col-md-7">
                            <input type="text" name="item_serie" id="item_serie" class="form-control"
                                placeholder="Ingresa el numero de serie" required>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="item_lot"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Lote:</b></label>
                        <div class="col-12 col-md-7">
                            <input type="text" name="item_lot" id="item_lot" class="form-control"
                                placeholder="Ingresa el lote">
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="item_caducity"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Caducidad:</b></label>
                        <div class="col-12 col-md-7">
                            <input type="text" name="item_caducity" id="item_caducity" class="form-control"
                                placeholder="Ingresa la caducidad">
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="item_color_primary"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Color
                                primario<span class="text-danger">*</span>:</b></label>
                        <div class="col-12 col-md-7">
                            <select name="item_color_primary" id="item_color_primary" class="custom-select" required>
                                <option value="">Selecciona un color...</option>
                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="item_color_secondary"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Color
                                secundario:</b></label>
                        <div class="col-12 col-md-7">
                            <select name="item_color_secondary" id="item_color_secondary" class="custom-select">
                                <option value="">Selecciona un color...</option>
                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="item_group"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Grupo:</b></label>
                        <div class="col-12 col-md-7">
                            <select name="item_group" id="item_group" class="custom-select">
                                <option value="">Selecciona un grupo...</option>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="item_family"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Familia:</b></label>
                        <div class="col-12 col-md-7">
                            <select name="item_family" id="item_family" class="custom-select">
                                <option value="">Selecciona una familia...</option>
                                <?php $__currentLoopData = $families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($family->id); ?>"><?php echo e($family->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="item_amount"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Cantidad<span
                                    class="text-danger">*</span>:</b></label>
                        <div class="col-12 col-md-7">
                            <input type="number" name="item_amount" id="item_amount" class="form-control"
                                placeholder="Cantidad del mismo articulo a ingresar" required>
                        </div>
                    </div>

                    <div class="row justify-content-center my-3 d-none" id="rowAlertItem">
                        <div class="col-10 text-center alert alert-danger font-weight-bolder">
                            Completa los campos con un <span class="text-danger">*</span>
                        </div>
                    </div>

                    <div class="row justify-content-center form-group">
                        <div class="col-auto">
                            <button type="button" class="btn btn-sm btn-secondary" id="btnCancelItem">Cancelar</button>
                        </div>
                        <div class="col-auto">
                            <?php if(Auth::user()->can('edit_inventory')): ?>
                                <button type="button" class="btn btn-sm btn-primary" id="btnAddItem">Agregar</button>
                            <?php else: ?>
                                <button type="button" class="btn btn-sm btn-dark" disabled>❌</button>
                            <?php endif; ?>

                        </div>
                    </div>

                </form>
            </div>

            <div class="h5 text-center font-weight-bolder">Lista de articulos a ingresar</div>



            <div class="col-10 text-center table-responsive">
                <table class="table table-sm table-bordered table-striped table-dark">
                    <thead>
                        <tr>
                            <th>Nombre articulo</th>
                            <th>N° Serie</th>
                            <th>Cantidad</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody id="tableItemsBody">

                    </tbody>
                </table>
            </div>
        </div>
        <div class="row justify-content-center my-3 d-none" id="rowEmptyAlert">
            <div class="col-10 text-center alert alert-danger font-weight-bolder">
                Necesitas ingresar almenos 1 artículo
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="cancelEntryModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-body bg-dark">
                    <div class="row justify-content-center my-3">
                        <div class="col-12 text-center text-light font-weight-bolder mb-3">
                            ¿Cancelar el ingreso?
                        </div>
                        <div class="col-auto">
                            <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">No,
                                continuar</button>
                        </div>
                        <div class="col-auto">
                            <a href="<?php echo e(route('entries')); ?>" class="btn btn-sm btn-danger">Si, cancelar</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js" defer></script>
    <script src="<?php echo e(asset('js/entry.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/inventory/entry/create.blade.php ENDPATH**/ ?>