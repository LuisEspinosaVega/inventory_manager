<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="h4 text-center">Detalles del item con ID: <b><?php echo e($item->id); ?></b></div>

        <div class="row justify-content-center my-4">
            <div class="col-12 col-md-4">
                
                <?php if($item->image): ?>
                    <img src="<?php echo e(asset('storage/' . $item->image)); ?>" class="img-fluid" alt="">
                <?php else: ?>
                    <img src="<?php echo e(asset('storage/item/no-image-item.svg')); ?>" class="img-fluid" alt="">
                <?php endif; ?>
            </div>
            <div class="col-12 col-md-8">
                <div class="row form-group h5">
                    <label for="" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Nombre
                            corto:</b></label>
                    <div class="col-12 col-md-7">
                        <?php echo e($item->catalog->name); ?>

                    </div>
                </div>

                <div class="row form-group h5">
                    <label for=""
                        class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Descripción:</b></label>
                    <div class="col-12 col-md-7">
                        <?php echo e($item->catalog->description); ?>

                    </div>
                </div>

                <div class="row form-group h5">
                    <label for="" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Numero de
                            serie:</b></label>
                    <div class="col-12 col-md-7">
                        <?php echo e($item->serial_number); ?>

                    </div>
                </div>

                <div class="row form-group h5">
                    <label for=""
                        class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Caducidad:</b></label>
                    <div class="col-12 col-md-7">
                        <?php echo e($item->caducity ?? 'N/A'); ?>

                    </div>
                </div>

                <div class="row form-group h5">
                    <label for="" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Lote:</b></label>
                    <div class="col-12 col-md-7">
                        <?php echo e($item->lot ?? 'N/A'); ?>

                    </div>
                </div>

                <div class="row form-group h5">
                    <label for="" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Grupo:</b></label>
                    <div class="col-12 col-md-7">
                        <?php if($item->group): ?>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($group->id == $item->group): ?>
                                    <?php echo e($group->name); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row form-group h5">
                    <label for=""
                        class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Familia:</b></label>
                    <div class="col-12 col-md-7">
                        <?php if($item->family): ?>
                            <?php $__currentLoopData = $families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($family->id == $item->family): ?>
                                    <?php echo e($family->name); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row form-group h5">
                    <label for="" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Color
                            primario:</b></label>
                    <div class="col-12 col-md-7">
                        <?php if($item->color_primary): ?>
                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($color->id == $item->color_primary): ?>
                                    <?php echo e($color->name); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row form-group h5">
                    <label for="" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Color
                            secundario:</b></label>
                    <div class="col-12 col-md-7">
                        <?php if($item->color_secondary): ?>
                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($color->id == $item->color_secondary): ?>
                                    <?php echo e($color->name); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row form-group h5">
                    <label for="" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Stock:</b></label>
                    <div class="col-12 col-md-7">
                        <?php echo e($item->stock); ?>

                    </div>
                </div>

                <div class="row form-group h5">
                    <label for="" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Fecha de
                            alta:</b></label>
                    <div class="col-12 col-md-7">
                        <?php echo e($item->created_at); ?>

                    </div>
                </div>

                <div class="row form-group justify-content-center justify-content-md-end">
                    <div class="col-auto text-center">
                        <a role="button" href="<?php echo e(route('items')); ?>" class="btn btn-sm btn-secondary">Regresar</a>
                    </div>
                    <div class="col-auto text-center">
                        <?php if(Auth::user()->can('edit_inventory')): ?>
                            <a role="button" href="<?php echo e(route('item.edit', $item->id)); ?>"
                                class="btn btn-sm btn-primary">Editar</a>
                        <?php else: ?>
                            <button type="button" class="btn btn-sm btn-dark" disabled>Editar</button>
                        <?php endif; ?>

                    </div>
                    
                </div>

            </div>
        </div>

        <div class="h4 text-center">Existencias en cada sucursal</div>
        <div class="row justify-content-center my-3">
            <div class="col-12 col-md-6 text-center">
                <table class="table table-sm table-dark table-hover table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>SUCURSAL</th>
                            <th>STOCK</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $existence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($office->id == $exist->office_id): ?>
                                            <?php echo e($office->name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php echo e($exist->stock); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="deleteItemModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body bg-dark">
                    <form action="<?php echo e(route('item.destroy')); ?>" method="post" id="deleteItemForm">
                        <?php echo csrf_field(); ?>
                        <div class="row justify-content-center p-1">
                            <input type="hidden" name="id_item" id="id_item">
                            <div class="col-12 text-center h5 text-light mb-3">
                                ¿Eliminar este articulo?
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-sm btn-light" data-dismiss="modal">Cancelar</button>
                            </div>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-sm btn-danger">Si, eliminar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('js/item/item-detail.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/inventory/items/detail.blade.php ENDPATH**/ ?>