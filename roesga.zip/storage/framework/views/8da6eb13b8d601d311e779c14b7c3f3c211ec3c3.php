<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="h4 text-center">Lista de variables</div>
        <div class="row justify-content-center justify-content-md-end mt-2">
            <div class="col-auto text-center mb-3">
                <a href="<?php echo e(route('admin.variables.create')); ?>" class="btn btn-sm btn-dark">Crear variable</a>
            </div>
        </div>
        <div class="row justify-content-center my-3">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-md-3 text-center my-1 p-2">
                    <div class="card">
                        <div class="card-header text-center bg-dark text-light p-1"><?php echo e($category->name); ?></div>
                        <div class="card-body text-center bg-light">
                            <?php $__currentLoopData = $variables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $var): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($var->category_id == $category->id): ?>
                                    <div class="row justify-content-center mt-1">
                                        <div class="col-8 text-center align-self-center">
                                            <?php echo e($var->name); ?>

                                        </div>
                                        <div class="col-4 text-center align-self-center">
                                            <a href="<?php echo e(route('admin.variables.edit', $var->id)); ?>"
                                                class="btn btn-sm btn-primary">Editar</a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/admin/variables/index.blade.php ENDPATH**/ ?>