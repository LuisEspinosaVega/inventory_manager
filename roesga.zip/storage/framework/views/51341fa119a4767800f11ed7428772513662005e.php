<?php $__env->startPush('filter-required'); ?>
    <script src="<?php echo e(asset('js/datatable.js')); ?>" defer></script>
    <link href="<?php echo e(asset('css/datatable.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="h4 text-center">Traspasos registrados</div>

        <div class="row justify-content-center justify-content-md-end">
            <div class="col-auto">
                <?php if(Auth::user()->can('edit_inventory')): ?>
                    <a role="button" href="<?php echo e(route('transfer.create')); ?>" class="btn btn-sm btn-dark">Generar traspaso de
                        artículos</a>
                <?php else: ?>
                    <button type="button" class="btn btn-sm btn-dark" disabled>❌</button>
                <?php endif; ?>
            </div>
        </div>

        <div class="row justify-content-center my-4">
            <div class="col-12 text-center table-responsive">
                <table class="table table-sm table-hover table-bordered table-striped" id="transferTable">
                    <thead class="bg-dark text-light">
                        <tr>
                            <th class=" d-none d-sm-none d-md-table-cell align-self-center">Fecha solicitud</th>
                            <th class=" d-none d-sm-none d-md-table-cell align-self-center">Última modificación</th>
                            <th>Sucursal orígen</th>
                            <th class=" d-none d-sm-none d-md-table-cell align-self-center">Encargado</th>
                            <th class=" d-none d-sm-none d-md-table-cell align-self-center">Solicitante</th>
                            <th class=" d-none d-sm-none d-md-table-cell align-self-center">Autoriza</th>
                            <th class=" d-none d-sm-none d-md-table-cell align-self-center">Recibe</th>
                            <th class=" d-none d-sm-none d-md-table-cell align-self-center">Estatus</th>
                            <th>Detalles</th>
                            <th>Cancelar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $text = '';
                                switch ($transfer->status) {
                                    case 'Solicitado':
                                        $text = 'text-primary';
                                        break;
                                    case 'Autorizado':
                                        $text = 'text-info';
                                        break;
                                    case 'Recibido':
                                        $text = 'text-success';
                                        break;
                                    case 'Cancelado':
                                        $text = 'text-danger';
                                        break;
                                }
                            ?>
                            <tr>
                                <td class=" d-none d-sm-none d-md-table-cell align-self-center"><?php echo e($transfer->created_at); ?>

                                </td>
                                <td class=" d-none d-sm-none d-md-table-cell align-self-center"><?php echo e($transfer->updated_at); ?>

                                </td>
                                <td><?php echo e($transfer->office->name); ?></td>
                                <td class=" d-none d-sm-none d-md-table-cell align-self-center"><?php echo e($transfer->mandated); ?>

                                </td>
                                <td class=" d-none d-sm-none d-md-table-cell align-self-center"><?php echo e($transfer->applicant); ?>

                                </td>
                                <td class=" d-none d-sm-none d-md-table-cell align-self-center">
                                    <?php echo e($transfer->authorizes ?? ''); ?></td>
                                <td class=" d-none d-sm-none d-md-table-cell align-self-center">
                                    <?php echo e($transfer->receive ?? ''); ?></td>
                                <td class=" d-none d-sm-none d-md-table-cell align-self-center <?php echo e($text); ?>">
                                    <?php echo e($transfer->status); ?></td>
                                <td>
                                    <a role="button" href="<?php echo e(route('transfer.detail', $transfer->id)); ?>"
                                        class="btn btn-sm btn-primary">Ir ⇗</a>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-danger"
                                        id="btnCancelTransfer">Cancelar</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('js/transfer-index.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/inventory/transfer/index.blade.php ENDPATH**/ ?>