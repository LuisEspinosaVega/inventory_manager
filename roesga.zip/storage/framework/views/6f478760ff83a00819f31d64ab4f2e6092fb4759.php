<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="h4 text-center">Detalles del ingreso con ID: <b><?php echo e($entry->id); ?></b></div>
        <div class="row justify-content-center justify-content-md-end">
            <a role="button" href="<?php echo e(route('entries')); ?>" class="btn btn-sm btn-dark">Regresar ⇖</a>
        </div>

        <div class="row justify-content-center my-4">
            <div class="col-12 col-md-8 h5 text-center">
                <div class="row form-group">
                    <div class="col-12 col-md-6 text-center text-md-right"><b>Fecha del ingreso:</b></div>
                    <div class="col-12 col-md-6 text-center text-md-left"><b><?php echo e($entry->created_at); ?></b></div>
                </div>
                <div class="row form-group">
                    <div class="col-12 col-md-6 text-center text-md-right"><b>Proveedor:</b></div>
                    <div class="col-12 col-md-6 text-center text-md-left"><b><?php echo e($entry->provider->name); ?></b></div>
                </div>
                <div class="row form-group">
                    <div class="col-12 col-md-6 text-center text-md-right"><b>Sucursal:</b></div>
                    <div class="col-12 col-md-6 text-center text-md-left"><b><?php echo e($entry->office->name); ?></b></div>
                </div>
                <div class="row form-group">
                    <div class="col-12 col-md-6 text-center text-md-right"><b>Encargado del ingreso:</b></div>
                    <div class="col-12 col-md-6 text-center text-md-left"><b><?php echo e($entry->mandated); ?></b></div>
                </div>
                <div class="row form-group">
                    <div class="col-12 col-md-6 text-center text-md-right"><b>Orden de compra:</b></div>
                    <div class="col-12 col-md-6 text-center text-md-left"><b><?php echo e($entry->purchase_order ?? "N/A"); ?></b></div>
                </div>
            </div>

        </div>

        <div class="row justify-content-center my-3">
            <div class="col-12 col-md-8 text-center table-responsive">
                <table class="table table-sm table-dark table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th>ARTICULO</th>
                            <th>N° SERIE</th>
                            <th>CANTIDAD</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($log->item->catalog->name); ?></td>
                                <td><?php echo e($log->item->serial_number); ?></td>
                                <td><?php echo e($log->amount); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/inventory/entry/detail.blade.php ENDPATH**/ ?>