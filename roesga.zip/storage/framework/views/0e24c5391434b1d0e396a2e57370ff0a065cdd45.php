<?php $__env->startPush('filter-required'); ?>
    <script src="<?php echo e(asset('js/datatable.js')); ?>" defer></script>
    <link href="<?php echo e(asset('css/datatable.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4 class="text-center">Existencias</h4>

        <div class="row justify-content-center my-4">
            <div class="col-12 text-center table-responsive">
                <table class="table table-sm table-bordered table-striped table-hover" id="itemsTable">
                    <thead class="bg-dark text-light">
                        <tr>
                            <th class=" d-none d-sm-none d-md-table-cell">ID</th>
                            <th>N° Serie</th>
                            <th>Catalogo</th>
                            <th>Stock</th>
                            <th class=" d-none d-sm-none d-md-table-cell">Fecha de alta</th>
                            <th class=" d-none d-sm-none d-md-table-cell">Ultima actualización</th>
                            <th>Detalle</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class=" d-none d-sm-none d-md-table-cell"><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->serial_number); ?></td>
                                <td><?php echo e($item->catalog->name); ?></td>
                                <td><?php echo e($item->stock); ?></td>
                                <td class=" d-none d-sm-none d-md-table-cell"><?php echo e($item->created_at); ?></td>
                                <td class=" d-none d-sm-none d-md-table-cell"><?php echo e($item->updated_at); ?></td>
                                <td>
                                    <a role="button" href="<?php echo e(route('item.details', $item->id)); ?>" class="btn btn-sm btn-primary">Ir ⇗</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="col-12 text-center">
                <?php echo e($items->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('js/item/item-index.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/inventory/items/index.blade.php ENDPATH**/ ?>