<?php $__env->startPush('filter-required'); ?>
    <script src="<?php echo e(asset('js/datatable.js')); ?>" defer></script>
    <link href="<?php echo e(asset('css/datatable.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="h4 text-center">Catalogo de inventario</div>
        <div class="row justify-content-center justify-content-md-end my-3">
            <?php if(Auth::user()->can('edit_inventory')): ?>
                <a role="button" href="<?php echo e(route('inventory.catalog.create')); ?>" class="btn btn-sm btn-dark">Dar de alta articulo en catalogo</a>
            <?php else: ?>
                <button type="button" class="btn btn-sm btn-dark" disabled>❌</button>
            <?php endif; ?>
        </div>

        <div class="row justify-content-center">
            
            <div class="col-6 col-md-3 text-center">
                <input type="text" name="search_name" id="search_name" class="form-control form-control-sm keys"
                    placeholder="Filtrar por nombre">
            </div>
            <div class="col-6 col-md-3 text-center">
                <input type="text" name="search_sku" id="search_sku" class="form-control form-control-sm keys"
                    placeholder="Filtrar por SKU">
            </div>
            <div class="col-6 col-md-3 text-center">
                <select name="search_category" id="search_category" class="custom-select custom-select-sm selects">
                    <option value="">Filtrar por categoria...</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-6 col-md-3 text-center">
                <select name="search_sub_category" id="search_sub_category" class="custom-select custom-select-sm selects">
                    <option value="">Filtrar por sub categoria...</option>
                    <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $csubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($csubCategory->id); ?>"><?php echo e($csubCategory->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        
        <div class="row justify-content-center mt-3">
            <div class="col-12 text-center table-responsive rounded">
                <table class="table table-sm table-bordered table-hover" id="catalogTable" style="width:100%">
                    <thead class="bg-dark text-light">
                        <tr>
                            <th>Nombre</th>
                            <th>SKU</th>
                            <th class=" d-none d-sm-none d-md-table-cell">Descripción</th>
                            <th>Detalles</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">

                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('js/catalog-list.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/inventory/catalog/index.blade.php ENDPATH**/ ?>