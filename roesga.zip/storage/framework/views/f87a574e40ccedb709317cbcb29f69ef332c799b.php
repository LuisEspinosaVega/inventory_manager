<?php $__env->startPush('filter-required'); ?>
    <script src="<?php echo e(asset('js/datatable.js')); ?>" defer></script>
    <link href="<?php echo e(asset('css/datatable.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="h4 text-center">Detalles <b><?php echo e($catalog->name); ?></b></div>
        <div class="row justify-content-center my-4">
            <div class="col-12 col-md-4">
                <?php if($catalog->image): ?>
                    <img src="<?php echo e(asset('storage/' . $catalog->image)); ?>" class="img-fluid" alt="Catalogo image">
                <?php else: ?>
                    <img src="<?php echo e(asset('storage/catalog/no-image-catalog.svg')); ?>" class="img-fluid" alt="Catalogo image">
                <?php endif; ?>
            </div>
            <div class="col-12 col-md-8 mt-3 mt-md-0">
                <div class="row form-group h5">
                    <label for="name" class="col-12 col-md-4 text-center text-md-right"><b>Nombre corto:</b></label>
                    <div class="col-12 col-md-8 text-center text-md-left">
                        <b><?php echo e($catalog->name); ?></b>
                    </div>
                </div>
                <div class="row form-group h5">
                    <label for="sku" class="col-12 col-md-4 text-center text-md-right"><b>SKU:</b></label>
                    <div class="col-12 col-md-8 text-center text-md-left">
                        <b><?php echo e($catalog->sku); ?></b>
                    </div>
                </div>

                <div class="row form-group h5">
                    <label for="sku" class="col-12 col-md-4 text-center text-md-right"><b>ARTICULOS:</b></label>
                    <div class="col-12 col-md-8 text-center text-md-left">
                        <b><?php echo e($catalog->items()->count()); ?></b>
                    </div>
                </div>

                <div class="row form-group h5">
                    <label for="description" class="col-12 col-md-4 text-center text-md-right"><b>Descripción:</b></label>
                    <div class="col-12 col-md-8 text-center text-md-left">
                        <b><?php echo e($catalog->description); ?></b>
                    </div>
                </div>
                <div class="row form-group h5">
                    <label for="category" class="col-12 col-md-4 text-center text-md-right"><b>Categoría:</b></label>
                    <div class="col-12 col-md-8 text-center text-md-left">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($category->id == $catalog->category): ?>
                                <b><?php echo e($category->name); ?></b>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="row form-group h5">
                    <label for="sub_category" class="col-12 col-md-4 text-center text-md-right"><b>Sub
                            categoría:</b></label>
                    <div class="col-12 col-md-8 text-center text-md-left">
                        <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($subCategory->id == $catalog->sub_category): ?>
                                <b><?php echo e($subCategory->name); ?></b>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="row form-group justify-content-center justify-content-md-end">
                    <div class="col-auto text-center">
                        <a role="button" href="<?php echo e(route('inventory.catalog')); ?>"
                            class="btn btn-sm btn-secondary">Regresar</a>
                    </div>
                    <div class="col-auto text-center">
                        <?php if(Auth::user()->can('edit_inventory')): ?>
                            <a role="button" href="<?php echo e(route('inventory.catalog.edit', $catalog->id)); ?>"
                                class="btn btn-sm btn-primary">Editar</a>
                        <?php else: ?>
                            <button type="button" class="btn btn-sm btn-dark" disabled>Editar</button>
                        <?php endif; ?>

                    </div>
                    <div class="col-auto text-center">
                        <?php if($catalog->items()->count() || !Auth::user()->can('edit_inventory')): ?>
                            <button type="button" class="btn btn-sm btn-dark" disabled>Eliminar</button>
                        <?php else: ?>
                            <button type="button" class="btn btn-sm btn-danger" data-idcatalog="<?php echo e($catalog->id); ?>"
                                data-toggle="modal" data-target="#deleteCatalogModal">Eliminar</button>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
        
        <div class="h4 text-center">Artículos del catálogo</div>
        <div class="row justify-content-center mt-3">
            <div class="col-12 col-md-10 text-center table-responsive">
                <table class="table table-sm table-striped table-bordered table-hover" id="catalogDetailTable">
                    <thead class="bg-dark text-light">
                        <tr>
                            <th>ID</th>
                            <th>N° serie</th>
                            <th>Stock</th>
                            <th>Detalles</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->serial_number); ?></td>
                                <td><?php echo e($item->stock); ?></td>
                                <td>
                                    <a href="<?php echo e(route('item.details', $item->id)); ?>" class="btn btn-sm btn-primary">Ir
                                        ⇗</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="deleteCatalogModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body bg-dark">
                    <form action="<?php echo e(route('inventory.catalog.destroy')); ?>" method="post" id="deleteCatalogForm">
                        <?php echo csrf_field(); ?>
                        <div class="row justify-content-center p-1">
                            <input type="hidden" name="id_catalog" id="id_catalog">
                            <div class="col-12 text-center h5 text-light mb-3">
                                ¿Eliminar este articulo?
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-sm btn-light" data-dismiss="modal">Cancelar</button>
                            </div>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-sm btn-danger">Si, eliminar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('js/inventory.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/inventory/catalog/detail.blade.php ENDPATH**/ ?>