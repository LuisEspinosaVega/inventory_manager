<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="h4 text-center">Editar item con ID: <b><?php echo e($item->id); ?></b></div>

        <div class="row justify-content-center my-4">
            <div class="col-12 col-md-4">
                
                <?php if($item->image): ?>
                    <img src="<?php echo e(asset('storage/' . $item->image)); ?>" class="img-fluid" alt="">
                <?php else: ?>
                    <img src="<?php echo e(asset('storage/item/no-image-item.svg')); ?>" class="img-fluid" alt="">
                <?php endif; ?>
            </div>
            <div class="col-12 col-md-8">

                <form action="<?php echo e(route('item.update', $item->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>

                    <div class="row form-group h5">
                        <label for="" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Nombre
                                corto:</b></label>
                        <div class="col-12 col-md-7">
                            <?php echo e($item->catalog->name); ?>

                        </div>
                    </div>

                    <div class="row form-group h5">
                        <label for=""
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Descripción:</b></label>
                        <div class="col-12 col-md-7">
                            <?php echo e($item->catalog->description); ?>

                        </div>
                    </div>

                    <div class="row form-group h5">
                        <label for="serial_number"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Numero de
                                serie:</b></label>
                        <div class="col-12 col-md-7">
                            <input type="text" name="serial_number" id="serial_number"
                                class="form-control <?php $__errorArgs = ['serial_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('serial_number') ?? $item->serial_number); ?>">

                            <?php $__errorArgs = ['serial_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group h5">
                        <label for="caducity"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Caducidad:</b></label>
                        <div class="col-12 col-md-7">
                            <input type="text" name="caducity" id="caducity"
                                class="form-control <?php $__errorArgs = ['caducity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('caducity') ?? $item->caducity); ?>">

                            <?php $__errorArgs = ['caducity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group h5">
                        <label for="lot"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Lote:</b></label>
                        <div class="col-12 col-md-7">
                            <input type="text" name="lot" id="lot" class="form-control <?php $__errorArgs = ['lot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('lot') ?? $item->lot); ?>">

                            <?php $__errorArgs = ['lot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group h5">
                        <label for="group"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Grupo:</b></label>
                        <div class="col-12 col-md-7">
                            <select name="group" id="group" class="custom-select <?php $__errorArgs = ['group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">Selecciona una categoría...</option>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($group->id); ?>" <?php if($group->id == $item->group): ?> selected <?php endif; ?>>
                                        <?php echo e($group->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group h5">
                        <label for="family"
                            class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Familia:</b></label>
                        <div class="col-12 col-md-7">
                            <select name="family" id="family" class="custom-select <?php $__errorArgs = ['family'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">Selecciona una categoría...</option>
                                <?php $__currentLoopData = $families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($family->id); ?>" <?php if($family->id == $item->family): ?> selected <?php endif; ?>>
                                        <?php echo e($family->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <?php $__errorArgs = ['family'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group h5">
                        <label for="color_primary" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Color
                                primario:</b></label>
                        <div class="col-12 col-md-7">
                            <select name="color_primary" id="color_primary" class="custom-select <?php $__errorArgs = ['color_primary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">Selecciona una categoría...</option>
                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($color->id); ?>" <?php if($color->id == $item->color_primary): ?> selected <?php endif; ?>>
                                        <?php echo e($color->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['color_primary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group h5">
                        <label for="color_secondary" class="col-12 col-md-5 text-center text-md-right align-self-center"><b>Color
                                secundario:</b></label>
                        <div class="col-12 col-md-7">
                            <select name="color_secondary" id="color_secondary" class="custom-select <?php $__errorArgs = ['color_secondary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">Selecciona una categoría...</option>
                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($color->id); ?>" <?php if($color->id == $item->color_secondary): ?> selected <?php endif; ?>>
                                        <?php echo e($color->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['color_secondary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="image" class="col-12 col-md-5 text-center text-md-right align-self-center h5"><b>Imagen especifica:</b></label>
                        <div class="col-12 col-md-7 text-center text-md-left">
                            <input type="file" name="image" id="image" accept="image/*" style="overflow: hidden;">
                            <?php if($errors->has('image')): ?>
                                <div class="col-12 text-center text-danger"><b><?php echo e($errors->first('image')); ?></b></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group justify-content-center justify-content-md-end">
                        <div class="col-auto text-center">
                            <a role="button" href="<?php echo e(route('items')); ?>" class="btn btn-sm btn-secondary">Regresar</a>
                        </div>
                        <div class="col-auto text-center">
                            <?php if(Auth::user()->can('edit_inventory')): ?>
                                <button type="submit" class="btn btn-sm btn-primary">Editar</button>
                            <?php else: ?>
                                <button type="button" class="btn btn-sm btn-dark" disabled>Editar</button>
                            <?php endif; ?>

                        </div>
                    </div>

                </form>

            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="deleteItemModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body bg-dark">
                    <form action="<?php echo e(route('item.destroy')); ?>" method="post" id="deleteItemForm">
                        <?php echo csrf_field(); ?>
                        <div class="row justify-content-center p-1">
                            <input type="hidden" name="id_item" id="id_item">
                            <div class="col-12 text-center h5 text-light mb-3">
                                ¿Eliminar este articulo?
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-sm btn-light" data-dismiss="modal">Cancelar</button>
                            </div>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-sm btn-danger">Si, eliminar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('js/item/item-detail.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/inventory/items/edit.blade.php ENDPATH**/ ?>