<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center my-3">
            <div class="col-12 h3 text-center">Modulo inventarios</div>
            <div class="col-md-8 my-5">
                <img src="<?php echo e(asset('storage/resources/inventory.svg')); ?>" alt="home image" class="img-fluid">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/inventory/index.blade.php ENDPATH**/ ?>