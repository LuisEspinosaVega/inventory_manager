<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="h4 text-center">Editar mi perfil</div>

        <div class="alert alert-warning alert-dismissible fade show text-center" role="alert">
            <b>Para cambiar tu correo electrónico debes solicitarlo al administrador.</b>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>

        <div class="row justify-content-center my-3">
            <div class="col-12 col-md-4 text-center">
                <?php if($user->profile->image): ?>
                    <img src="<?php echo e(asset('storage/' . $user->profile->image)); ?>" alt="" class="img-fluid rounded-circle">
                <?php else: ?>
                    <img src="<?php echo e(asset('storage/profiles/no-image-profile.svg')); ?>" alt="" class="img-fluid">
                <?php endif; ?>
            </div>
            <div class="col-12 col-md-8">
                <form action="<?php echo e(route('profile.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>

                    <div class="row form-group">
                        <div class="col-12 col-md-4 text-center text-md-right"><b>Username:</b></div>
                        <div class="col-12 col-md-8 text-center text-md-left h5"><b><?php echo e($user->name); ?></b></div>
                    </div>
                    <div class="row form-group">
                        <div class="col-12 col-md-4 text-center text-md-right"><b>Email:</b></div>
                        <div class="col-12 col-md-8 text-center text-md-left h5"><b><?php echo e($user->email); ?></b></div>
                    </div>
                    <div class="row form-group">
                        <label for="first_name"
                            class="col-12 col-md-4 text-center text-md-right align-self-center"><b>Nombre:</b></label>
                        <div class="col-12 col-md-8 text-center text-md-left h5">
                            <input type="text" name="first_name" id="first_name"
                                class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ingresa tus nombres"
                                value="<?php echo e(old('first_name') ?? $user->profile->first_name); ?>">
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row form-group">
                        <label for="last_name"
                            class="col-12 col-md-4 text-center text-md-right align-self-center"><b>Apellido:</b></label>
                        <div class="col-12 col-md-8 text-center text-md-left h5">
                            <input type="text" name="last_name" id="last_name"
                                class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Ingresa tus apellidos"
                                value="<?php echo e(old('last_name') ?? $user->profile->last_name); ?>">
                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row form-group">
                        <label for="phone"
                            class="col-12 col-md-4 text-center text-md-right align-self-center"><b>Telefono:</b></label>
                        <div class="col-12 col-md-8 text-center text-md-left h5">
                            <input type="number" name="phone" id="phone"
                                class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="10 digitos"
                                value="<?php echo e(old('phone') ?? $user->profile->phone); ?>">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="password"
                            class="col-12 col-md-4 text-center text-md-right align-self-center"><b>Contraseña:</b></label>
                        <div class="col-12 col-md-8 text-center text-md-left h5">
                            <input type="password" name="password" id="password"
                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nueva contraseña">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <label for="image" class="col-12 col-md-4 text-center text-md-right align-self-center"><b>Foto de
                                perfil:</b></label>
                        <div class="col-12 col-md-8 text-center text-md-left h5">
                            <input type="file" name="image" id="image" accept="image/*" style="overflow: hidden;">
                            <?php if($errors->has('image')): ?>
                                <div class="col-12 text-center text-danger"><b><?php echo e($errors->first('image')); ?></b></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row justify-content-center form-group">
                        
                        <div class="col-auto">
                            <a role="button" href="<?php echo e(route('home')); ?>" class="btn btn-secondary btn-sm">Cancelar</a>
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-sm btn-primary">Actualizar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            <b><?php echo e(session('success')); ?></b>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/profile.blade.php ENDPATH**/ ?>