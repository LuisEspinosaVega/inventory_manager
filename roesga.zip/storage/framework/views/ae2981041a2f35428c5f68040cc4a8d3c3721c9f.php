<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="h4 text-center">Lista de categorías</div>
        <div class="row justify-content-center justify-content-md-end mt-2">
            <div class="col-auto text-center mb-3">
                <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-sm btn-dark">Crear categoría</a>
            </div>
        </div>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row justify-content-center form-group border p-2">
                <div class="col-10 col-md-4 text-center">
                    <?php echo e($category->name); ?>

                </div>
                <div class="col-2 text-center">
                    <a role="button" href="<?php echo e(route('admin.categories.edit', $category->id)); ?>"
                        class="btn btn-sm btn-primary">Editar</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>