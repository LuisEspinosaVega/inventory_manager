<?php $__env->startPush('filter-required'); ?>
    <script src="<?php echo e(asset('js/datatable.js')); ?>" defer></script>
    <link href="<?php echo e(asset('css/datatable.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4 class="text-center">Salidas registradas</h4>

        <div class="row justify-content-center justify-content-md-end">
            <div class="col-auto">
                <?php if(Auth::user()->can('edit_inventory')): ?>
                    <a role="button" href="<?php echo e(route('outlet.create')); ?>" class="btn btn-sm btn-dark">Generar salida de
                        artículos</a>
                <?php else: ?>
                    <button type="button" class="btn btn-sm btn-dark" disabled>❌</button>
                <?php endif; ?>
            </div>
        </div>

        <div class="row justify-content-center my-4">
            <div class="col-12 text-center table-responsitve">
                <table class="table table-sm table-bordered table-hover table-striped" id="outletsTable">
                    <thead class="bg-dark text-light">
                        <tr>
                            <th>Fecha</th>
                            <th>Sucursal</th>
                            <th class=" d-none d-sm-none d-md-table-cell">Encargado</th>
                            <th class=" d-none d-sm-none d-md-table-cell">Usuario de sistema</th>
                            <th>Detalle</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($outlet->created_at); ?></td>
                                <td><?php echo e($outlet->office->name); ?></td>
                                <td class=" d-none d-sm-none d-md-table-cell"><?php echo e($outlet->mandated); ?></td>
                                <td class=" d-none d-sm-none d-md-table-cell"><?php echo e($outlet->user->name); ?></td>
                                <td>
                                    <a role="button" href="<?php echo e(route('outlet.detail', $outlet->id)); ?>"
                                        class="btn btn-sm btn-primary">Ir ⇗</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('js/outlet-index.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/inventory/outlet/index.blade.php ENDPATH**/ ?>