<?php $__env->startPush('filter-required'); ?>
    <script src="<?php echo e(asset('js/datatable.js')); ?>" defer></script>
    <link href="<?php echo e(asset('css/datatable.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4 class="text-center">Ingresos registrados</h4>

        <div class="row justify-content-center justify-content-md-end">
            <div class="col-auto">
                <?php if(Auth::user()->can('edit_inventory')): ?>
                <a role="button" href="<?php echo e(route('entry.create')); ?>" class="btn btn-sm btn-dark">Generar ingreso de
                    artículos</a>
                <?php else: ?>
                    <button type="button" class="btn btn-sm btn-dark" disabled>❌</button>
                <?php endif; ?>
            </div>
        </div>

        <div class="row justify-content-center my-3">
            <div class="col-12">
                

            </div>

            
            <div class="col-12 text-center table-responsive">
                <table class="table table-sm table-bordered table-striped" id="entriesTable">
                    <thead class="bg-dark text-light">
                        <tr>
                            <th>Fecha</th>
                            <th>Sucursal</th>
                            <th class=" d-none d-sm-none d-md-table-cell">Proveedor</th>
                            <th class=" d-none d-sm-none d-md-table-cell">Encargado</th>
                            <th class=" d-none d-sm-none d-md-table-cell">Usuario de sistema</th>
                            <th>Detalles</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($entry->created_at); ?></td>
                                <td><?php echo e($entry->office->name); ?></td>
                                <td class=" d-none d-sm-none d-md-table-cell"><?php echo e($entry->provider->name); ?></td>
                                <td class=" d-none d-sm-none d-md-table-cell"><?php echo e($entry->mandated); ?></td>
                                <td class=" d-none d-sm-none d-md-table-cell"><?php echo e($entry->user->name); ?></td>
                                <td>
                                    <a role="button" href="<?php echo e(route('entry.detail', $entry->id)); ?>"
                                        class="btn btn-sm btn-primary">Ir ⇗</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('js/entry-index.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\luiza\OneDrive\Desktop\Laravel Projects\roesga\resources\views/inventory/entry/index.blade.php ENDPATH**/ ?>