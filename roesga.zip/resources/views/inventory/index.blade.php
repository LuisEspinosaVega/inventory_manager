@extends('layouts.inventory')

@section('content')
    <div class="container">
        <div class="row justify-content-center my-3">
            <div class="col-12 h3 text-center">Modulo inventarios</div>
            <div class="col-md-8 my-5">
                <img src="{{ asset('storage/resources/inventory.svg') }}" alt="home image" class="img-fluid">
            </div>
        </div>
    </div>
@endsection
