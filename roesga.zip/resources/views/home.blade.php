@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center my-3">
            <div class="col-12 h4 text-center">Página principal</div>
            <div class="col-md-8 my-5">
                <img src="{{ asset('storage/resources/home.svg') }}" alt="home image" class="img-fluid">
            </div>
        </div>
    </div>
@endsection
