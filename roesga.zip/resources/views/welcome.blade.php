@extends('layouts.app')

@section('content')
    Hola mundo
@endsection
