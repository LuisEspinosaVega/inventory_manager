<?php

namespace App\Http\Controllers;

use App\Models\Catalog;
use App\Models\Category;
use App\Models\Item;
use App\Models\Log;
use App\Models\Variable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class InventoryController extends Controller
{
    public $main_inventory = false;
    public $edit_inventory = false;

    public function __construct()
    {
        $this->middleware('can:main_inventory');
        $this->middleware('auth');
    }

    public function index()
    {
        return view('inventory.index');
    }

    // handle catalog-----------------------------------------------------------------------------------------
    public function catalog()
    {
        //Mandar las variables para los filtros (*￣3￣)╭
        $categoria = Category::select('id')->where('name', 'Categoria producto')->pluck('id')[0];
        $subCategoria = Category::select('id')->where('name', 'Sub categoria producto')->pluck('id')[0];

        $categories = Variable::where('category_id', $categoria)->get();
        $subCategories = Variable::where('category_id', $subCategoria)->get();
        // dd($categories);

        return view('inventory.catalog.index', compact('categories', 'subCategories'));
    }
    //Funcion para las peticiones AJAX para usar filtros
    public function filtersCatalog(Request $request)
    {
        $name = $request->name;
        $sku = $request->sku;
        $category = $request->category;
        $subCategory = $request->sub_category;

        $name_query = ['id', '>', 0];
        $sku_query = ['id', '>', 0];
        $category_query = ['id', '>', 0];
        $subCategory_query = ['id', '>', 0];

        if ($name != "") {
            $name_query = ['name', 'LIKE', '%' . $name . '%'];
        }
        if ($sku != "") {
            $sku_query = ['sku', 'LIKE', '%' . $sku . '%'];
        }
        if ($category != "") {
            $category_query = ['category', '=', $category];
        }
        if ($subCategory != "") {
            $subCategory_query = ['sub_category', '=', $subCategory];
        }

        $catalog = Catalog::select('name', 'description', 'sku', 'id')->where([
            $name_query,
            $sku_query,
            $category_query,
            $subCategory_query
        ])->orderBy('name', 'asc')->get();

        return json_encode($catalog);
    }

    public function createCatalog()
    {
        //Mandar las variables para los filtros (*￣3￣)╭
        $categoria = Category::select('id')->where('name', 'Categoria producto')->pluck('id')[0];
        $subCategoria = Category::select('id')->where('name', 'Sub categoria producto')->pluck('id')[0];

        $categories = Variable::where('category_id', $categoria)->get();
        $subCategories = Variable::where('category_id', $subCategoria)->get();

        return view('inventory.catalog.create', compact('categories', 'subCategories'));
    }

    public function storeCatalog(Request $request)
    {
        $request->validate([
            'name' => ['required', 'string', 'min:5', 'max:255', 'unique:catalogs'],
            'description' => ['required', 'min:10', 'string'],
            'category' => ['required'],
            'sub_category' => ['nullable'],
            'image' => ['image']
        ]);

        if ($request->image) {
            //Guardar la imagen en el servidor
            $path = $request->image->store('catalog', 'public');
        } else {
            $path = null;
        }

        $sku = "SKU-" . strtoupper(substr($request->name, 0, 3)) . date("dis");

        Catalog::create([
            'name' => $request->name,
            'sku' => $sku,
            'description' => $request->description,
            'category' => $request->category,
            'sub_category' => $request->sub_category,
            'image' => $path,
            'created_by' => Auth::user()->id
        ]);

        return redirect('/inventory/catalog');
    }

    public function detailCatalog(Catalog $catalog)
    {
        //Mandar las variables para los filtros (*￣3￣)╭
        $categoria = Category::select('id')->where('name', 'Categoria producto')->pluck('id')[0];
        $subCategoria = Category::select('id')->where('name', 'Sub categoria producto')->pluck('id')[0];

        $categories = Variable::where('category_id', $categoria)->get();
        $subCategories = Variable::where('category_id', $subCategoria)->get();

        $items = Item::select('serial_number', 'stock', 'id')->where('catalog_id', '=', $catalog->id)->get();

        return view('inventory.catalog.detail', compact('catalog', 'categories', 'subCategories','items'));
    }

    public function editCatalog(Catalog $catalog)
    {
        //Mandar las variables para los filtros (*￣3￣)╭
        $categoria = Category::select('id')->where('name', 'Categoria producto')->pluck('id')[0];
        $subCategoria = Category::select('id')->where('name', 'Sub categoria producto')->pluck('id')[0];

        $categories = Variable::where('category_id', $categoria)->get();
        $subCategories = Variable::where('category_id', $subCategoria)->get();

        return view('inventory.catalog.edit', compact('catalog', 'categories', 'subCategories'));
    }

    public function updateCatalog(Request $request, Catalog $catalog)
    {
        $request->validate([
            'name' => ['required', 'string', 'min:5', 'max:255', "unique:catalogs,name,{$catalog->id},id"],
            'description' => ['required', 'min:10', 'string'],
            'category' => ['required'],
            'sub_category' => ['nullable'],
            'image' => ['image']
        ]);

        if ($request->image) {
            //Guardar la imagen en el servidor
            if ($catalog->image) {
                unlink('storage/' . $catalog->image);
            }

            $path = $request->image->store('catalog', 'public');

            $catalog->image = $path;
        }

        $catalog->name = $request->name;
        $catalog->description = $request->description;
        $catalog->category = $request->category;
        $catalog->sub_category = $request->sub_category;
        $catalog->updated_by = Auth::user()->id;

        $catalog->save();

        return redirect('/inventory/catalog');
    }

    public function destroyCatalog(Request $request)
    {
        $catalog = Catalog::find($request->id_catalog);
        if ($catalog->image) {
            unlink('storage/' . $catalog->image);
        }

        $catalog->delete();
        return "ok";
    }

    //historial de movimientos
    public function history()
    {
        $logs = Log::all();
        return view('inventory.history', compact('logs'));
    }
}
